# Nome do projeto
Escreva um ou dois  parágrafo resumindo o objetivo do seu projeto.

## Alunos integrantes da equipe

* Nome completo do aluno 1
* Nome completo do aluno 2
* Nome completo do aluno 3
* Nome completo do aluno 4

## Professores responsáveis

* Nome completo do professor 1
* Nome completo do professor 2

## Instruções de utilização

Assim que a primeira versão do sistema estiver disponível, deverá complementar com as instruções de utilização. Descreva como instalar eventuais dependências e como executar a aplicação.
